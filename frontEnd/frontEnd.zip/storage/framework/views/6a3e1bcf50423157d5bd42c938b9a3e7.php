<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>My Store || <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontEnd/assets/images/favicon.png')); ?>">

    <!-- CSS
    ============================================ -->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/flaticon/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/slick-theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/jquery-uassets/css/vendor/sal.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/vendor/base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontEnd/assets/css/style.min.css')); ?>">
    <?php echo $__env->yieldPushContent('style'); ?>
</head>


<body>
    <a href="#top" class="back-to-top" id="backto-top"><i class="fal fa-arrow-up"></i></a>
    <!-- Start Header -->
    <?php echo $__env->make('frontEnd.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Start Header End -->

    <?php echo $__env->yieldContent('main-content'); ?>


    
    <?php echo $__env->make('frontEnd.partials.service-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    

    <!-- Start Footer Area  -->
    <?php echo $__env->make('frontEnd.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Footer Area  -->

    <!-- Product Quick View Modal Start -->
    <?php echo $__env->make('frontEnd.partials.product-quick-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Product Quick View Modal End -->

    <!-- Header Search Modal End -->
    <?php echo $__env->make('frontEnd.partials.header-search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header Search Modal End -->


    
    <?php echo $__env->make('frontEnd.partials.cart-dropdown', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    


    <!-- JS
============================================ -->
    <!-- Modernizer JS -->
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/modernizr.min.js')); ?>"></script>
    <!-- jQuery JS -->
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/jquery.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/js.cookie.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('frontEnd/assets/js/vendor/jquery.style.switcher.js')); ?>"></script> -->
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/jquery.countdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/sal.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/counterup.js')); ?>"></script>
    <script src="<?php echo e(asset('frontEnd/assets/js/vendor/waypoints.min.js')); ?>"></script>

    <!-- Main JS -->
    <script src="<?php echo e(asset('frontEnd/assets/js/main.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>
<?php /**PATH D:\xampp\htdocs\my-store\resources\views/frontEnd/partials/app.blade.php ENDPATH**/ ?>